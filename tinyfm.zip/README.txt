#########################################
# Copyleft 2023 Tisaros Obengkumana     #
# Install TinyFM with PHP8              #
#########################################

# opkg update
# opkg install php8-cgi php8-mod-session php8-mod-ctype php8-mod-fileinfo php8-mod-mbstring php8-mod-iconv zoneinfo-asia


    
